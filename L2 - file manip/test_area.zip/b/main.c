//
//  main.c
//  lab2_xcode
//
//  Created by Christian Benincasa on 1/29/13.
//  Copyright (c) 2013 Christian Benincasa. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>

int main(int argc, const char * argv[])
{
  
  
  return EXIT_SUCCESS;
}

