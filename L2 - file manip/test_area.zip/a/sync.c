#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <errno.h>
#include "csapp.h"

const int MAX_DIRNAME_LEN = 1024;
void scan_dir(const char *dirname, const char *path, const char* sync_dir, int mode);
void sync_directories(const char *master, const char *slave);
char* find_file_in_dir(const char* dir_to_search, const char* file_path);

int main(int argc, const char * argv[])
{
  DIR *master, *slave;
  struct dirent *master_meta, *slave_meta;
  if(argc < 3) {
    fprintf(stderr, "Insufficient argument count");
    exit(1);
  }
  
  if(!(master = opendir(argv[1]))) {
    fprintf(stderr, "Couldn't open master directory.\n");
    exit(EXIT_FAILURE);
  }
  if(!(slave = opendir(argv[2]))) {
    fprintf(stderr, "Couldn't open slave directory.\n");
    exit(EXIT_FAILURE);
  }
  
  sync_directories(argv[1], argv[2]);
  closedir(master);
  closedir(slave);
  return EXIT_SUCCESS;
}

/**
 *
 * int mode
 *    0 : master mode (master searching contents of slave)
 *    1 : slave mode (slave searching contents of master)
 *
 **/

void sync_directories(const char *master, const char *slave) {
  printf("Scanning %s...\n", master);
  scan_dir(master, NULL, slave, 0);
  //printf("Scanning %s...\n", slave);
  //scan_dir(slave, NULL, master, 1);
}

void scan_dir(const char* dirname, const char* path, const char* sync_dir, int mode) {
  // If dirname is self or parent, stop
  if(strncmp(dirname, "..", strlen(dirname)) == 0 || strncmp(dirname, ".", strlen(dirname)) == 0) {
    return;
  }
  else {
    DIR* dir;
    struct dirent* dir_meta;
    struct stat* current_file_stat;
    char* search_path = (char*) malloc(sizeof(char) * MAX_DIRNAME_LEN);
    int path_length;
    
    //scanning subdir
    if(path) {
      path_length = snprintf(search_path, MAX_DIRNAME_LEN, "%s/%s", path, dirname);
    } else {
      strncpy(search_path, dirname, strlen(dirname) + 1);
    }
    if(!(dir = opendir(search_path))) {
      fprintf(stderr, "Couldn't open directory %s.\n", dirname);
      return;
    } else {
      current_file_stat = malloc(sizeof(struct stat));
      while((dir_meta = readdir(dir))) {
        // Found a subdirectory -- recurse
        if(dir_meta->d_type == DT_DIR) {
          scan_dir(dir_meta->d_name, dirname, sync_dir, mode);
        } else {
          // Nope, we're looking at a file
          int stat_success;
          char *file_path = (char*) malloc(sizeof(char) * MAX_DIRNAME_LEN);
          // If there's a path param, construct correct relative path to file
          // Else, we're in the base of the dir, so append base dir name
          if(path) {
            snprintf(file_path, MAX_DIRNAME_LEN, "%s/%s", search_path, dir_meta->d_name);
          } else {
            snprintf(file_path, MAX_DIRNAME_LEN, "%s/%s", dirname, dir_meta->d_name);
          }
          if((stat_success = stat(file_path, current_file_stat)) == 0) {
            if(S_ISREG(current_file_stat->st_mode) && (current_file_stat->st_mode & S_IRUSR)) {
              char* found_file;
              // If the file is in a subdirectory, construct the relative path
              // Else, just pass along the filename as it is in the base dir
              if(path) {
                char* relative_path = (char*) malloc(sizeof(char) * MAX_DIRNAME_LEN);
                snprintf(relative_path, MAX_DIRNAME_LEN, "%s/%s", dirname, dir_meta->d_name);
                found_file = find_file_in_dir(sync_dir, relative_path);
                free(relative_path);
              } else {
                found_file = find_file_in_dir(sync_dir, dir_meta->d_name);
              }
              // If found file is null, the file isn't present in the searched dir -- do appropriate ops
              // Else, the file is there, disregard mode, overwrite older file
              if(found_file == NULL) {
                if(mode) {
                  if(remove(file_path) != 0) {
                    printf("Error deleting %s.\n", file_path);
                  } else {
                    printf("%s successfully deleted from memory.\n", file_path);
                  }
                } else {
                  // Master mode, copy to slave directory
                  // found_file should contain the correct path to copy to.
                  FILE* src_file, *dest_file;
                  char* dest_file_path = (char*) malloc(sizeof(char) * MAX_DIRNAME_LEN);
                  char* dest_dir_path = (char*) malloc(sizeof(char) * MAX_DIRNAME_LEN);
                  if(path) {
                    snprintf(dest_dir_path, MAX_DIRNAME_LEN, "%s/%s", sync_dir, dirname);
                    snprintf(dest_file_path, MAX_DIRNAME_LEN, "%s/%s", dest_dir_path, dir_meta->d_name);
                  } else {
                    strncpy(dest_dir_path, sync_dir, MAX_DIRNAME_LEN);
                    snprintf(dest_file_path, MAX_DIRNAME_LEN, "%s/%s", dest_dir_path, dir_meta->d_name);
                  }
                  if((src_file = fopen(file_path, "r"))) {
                    //first check for dir
                    DIR* dest_dir;
                    if(!(dest_dir = opendir(dest_dir_path))) {
                      printf("About to create %s\n", dest_dir_path);
                      mkdir(dest_dir_path, 0777);
                    } else {
                      closedir(dest_dir);
                    }
                    printf("About to create %s\n", dest_file_path);
                    if((dest_file = fopen(dest_file_path, "w"))) {
                      puts("ok!");
                      char* buf = (char*) malloc(sizeof(char) * 1024);
                      long n;
                      while(feof(src_file) == 0) {
                        puts("READ");
                        n = fread(buf, 1024, 1, src_file);
                        if(n < 1 && ferror(src_file)) {
                          puts("read error");
                          break;
                        }
                        printf("%s\n", buf);
                      }
                      fclose(dest_file);
                    } else {
                      puts("something went wrong with creating file.");
                    }
                    fclose(src_file);
                  } else {
                      puts("uh oh\n");                    
                  }
                  free(dest_file_path);
                  free(dest_dir_path);
                }
              } else {
                // found_file has the path of a file. compare the current file and found_file
                struct stat* found_file_meta = (struct stat*) malloc(sizeof(struct stat));
                long original_file_time, found_file_time;
                original_file_time = current_file_stat->st_mtime;
                puts(found_file);
                if((stat(found_file, found_file_meta)) == 0) {
                  found_file_time = found_file_meta->st_mtime;
                  if(original_file_time > found_file_time) {
                    puts("File in original directory is more recent");
                  }
                  else if(found_file_time < original_file_time) {
                    puts("File in checked directory is more recent");
                  }
                  free(found_file_meta);
                } else {
                  puts("stat error");
                }
              }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readable, return name!
      free(file_stat);
      return search_rel_path;
    }
  }
  free(search_rel_path);
  free(file_stat);
  return NULL;
}    }
              free(found_file);
            }
          } else {
            fprintf(stderr, "%s\n", strerror(errno));
          }
          free(file_path);
        }
      }
      free(current_file_stat);
      free(dir_meta);
      closedir(dir);
    }
    free(search_path);
  }
}

char* find_file_in_dir(const char* dir_to_search, const char* file_path) {
  FILE* search_file;
  struct stat* file_stat = (struct stat *) malloc(sizeof(struct stat));
  int stat_success;
  char* search_rel_path = (char*) Malloc(sizeof(char) * MAX_DIRNAME_LEN);
  snprintf(search_rel_path, MAX_DIRNAME_LEN, "%s/%s", dir_to_search, file_path);
  printf("Looking for %s.\n", search_rel_path);
  stat_success = stat(search_rel_path, file_stat);
  if(stat_success == 0) {
    if(S_ISREG(file_stat->st_mode) && (file_stat->st_mode & S_IRUSR)) {
      printf("Something!\n");
      //File is readab